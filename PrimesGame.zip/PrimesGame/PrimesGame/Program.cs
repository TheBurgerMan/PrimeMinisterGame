﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace PrimesGame
{
    class ProgramStart
    {
        static bool nameCheck;
        static string tempName;

        static void Main(string[] args)
        {
            do
            {
                Console.Clear();
                Console.WriteLine("Welcome to the game!");
                Console.Write("Please enter your name: ");
                tempName = Console.ReadLine();
                nameCheck = ValidName(tempName);
            } while (!nameCheck);
            Player.name = tempName;
            Player.score = 0;
            Game.GameChoice();
        }

        static bool ValidName(string name)
        {
            if (String.IsNullOrEmpty(name))
            {
                return false;
            }
            foreach (var letter in name)
            {
                if (!char.IsLetter(letter))
                {
                    return false;
                }
            }
            return true;
        }
    }

    class Game
    {
        public static List<string> ministerNames = new List<string>();
        public static List<string> ministerStarts = new List<string>();
        public static List<string> ministerRecords = new List<string>();
        public static string modeChoice;


        public static void GameChoice()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("------Please choose a gamemode------");
                Console.WriteLine("1) Guess the earliest minister!");
                Console.WriteLine("2) Match the minister to the term!");
                modeChoice = Console.ReadLine();
            } while (modeChoice != "1" && modeChoice != "2");
            switch (modeChoice)
            {
                case "1":
                    EarliestMinisterGameMode();
                    break;
                case "2":
                    MatchTheMinisterGameMode();
                    break;
                default:
                    break;
            }
            DisplayEndScore();
        }

        private static void MatchTheMinisterGameMode()
        {
            Player.score = 0;
            ReadCSVFile();
            Console.Clear();
            int rindex1 = 0;
            int rindex2 = 0;
            int rindex3 = 0;
            int qnum = 1;
            while (qnum < 6)
            {
                try
                {
                    GenRanMinisters(ref rindex1, ref rindex2, ref rindex3); //Generates 3 indexes used to select ministers from list
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Input any key to continue.");
                    Console.ReadLine();
                    continue;
                }
                try
                {
                    GenTermQuestion(rindex1, rindex2, rindex3, qnum); // Method used to display questions
                    qnum++;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Input any key to continue.");
                    Console.ReadLine();
                    continue;
                }
            }
        }

        private static void EarliestMinisterGameMode()
        {
            Player.score = 0;
            ReadCSVFile();
            Console.Clear();
            int rindex1 = 0;
            int rindex2 = 0;
            int rindex3 = 0;
            int qnum = 1;
            while (qnum < 6)
            {
                try
                {
                    GenRanMinisters(ref rindex1, ref rindex2, ref rindex3); //Generates 3 indexes used to select ministers from list
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Input any key to continue.");
                    Console.ReadLine();
                    continue;
                }
                try
                {
                    GenEarlyQuestion(rindex1, rindex2, rindex3, qnum); // Method used to display questions
                    qnum++;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Input any key to continue.");
                    Console.ReadLine();
                    continue;
                }
            }
        }

        private static void GenEarlyQuestion(int i1, int i2, int i3, int qnum)
        {
            string answer;
            Console.WriteLine($"--------------------------Question {qnum}----------------------------");
            Console.WriteLine($"1) {ministerNames[i1]} ");
            Console.WriteLine($"2) {ministerNames[i2]} ");
            Console.WriteLine($"3) {ministerNames[i3]} ");
            DateTime term1 = DateTime.Parse(ministerStarts[i1]);
            DateTime term2 = DateTime.Parse(ministerStarts[i2]);
            DateTime term3 = DateTime.Parse(ministerStarts[i3]);
            string userChoice = Console.ReadLine();
            try
            {
                answer = CalculateAnswer(term1, term2, term3);
                if (userChoice.Equals(answer))
                {
                    Player.score++;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Input any key to continue.");
                Console.ReadLine();
            }


        }

        private static void GenTermQuestion(int i1, int i2, int i3, int qnum)
        {
            Random rnd = new Random();
            List<string> randomTerms = new List<string> {ministerStarts[i1], ministerStarts[i2], ministerStarts[i3] };
            int ranTermIndex = rnd.Next(0, 3);
            string randomTerm = randomTerms[ranTermIndex];
            Console.WriteLine($"--------------------------Question {qnum}----------------------------");
            Console.WriteLine($"Which of the following PMs served on this date: {randomTerm}");
            Console.WriteLine($"1) {ministerNames[i1]} ");
            Console.WriteLine($"2) {ministerNames[i2]} ");
            Console.WriteLine($"3) {ministerNames[i3]} ");
            string userChoice = Console.ReadLine();
            switch (userChoice)
            {
                case "1":
                    string pmTerm1 = randomTerms[0];
                    if (pmTerm1.Equals(randomTerm))
                    {
                        Player.score++;
                    }
                    break;
                case "2":
                    string pmTerm2 = randomTerms[1];
                    if (pmTerm2.Equals(randomTerm))
                    {
                        Player.score++;
                    }
                    break;
                case "3":
                    string pmTerm3 = randomTerms[2];
                    if (pmTerm3.Equals(randomTerm))
                    {
                        Player.score++;
                    }
                    break;
                default:
                    break;
            }
        }

        private static void ReadCSVFile()
        {
            using (StreamReader file = new StreamReader(@"..\..\list_of_prime_ministers_of_uk-1-UPDATE.csv"))
            {
                file.ReadLine(); // Stops the column headers row from being read
                while (!file.EndOfStream) // Do the following while the entire file has not been read
                {
                    var line = file.ReadLine(); // stores the row from CSV into a string var
                    var values = line.Split(','); //Splits the values apart using ',' as limiter
                    ministerNames.Add(values[1]); // Adds first value from each record (prime Minister name) into names list
                    ministerStarts.Add(values[3]); //Same as the former but with each minister start date
                }
                for (int i = 0; i < ministerNames.Count; i++) //Creates a single string of format 'NAME|STARTDATE' and adds to record list per minister
                {
                    ministerRecords.Add($"{ministerNames[i]}|{ministerStarts[i]}");
                }
            }
        }

        private static void GenRanMinisters(ref int rindex1, ref int rindex2, ref int rindex3)
        {
            Random rnd = new Random();

            rindex1 = rnd.Next(0, ministerRecords.Count());
            rindex2 = rnd.Next(0, ministerRecords.Count());
            rindex3 = rnd.Next(0, ministerRecords.Count());

            if ((rindex1 != rindex2 && rindex1 != rindex3) && (rindex2 != rindex1 && rindex2 != rindex3) && (rindex3 != rindex1 && rindex3 != rindex2))
            {
                //nothing happens
            }
            else
            {
                throw new SameIndexException(); // Exception is thrown
            }

            string tempname1 = ministerNames[rindex1];
            string tempname2 = ministerNames[rindex2];
            string tempname3 = ministerNames[rindex3];

            if ((tempname1 != tempname2 && tempname1 != tempname3) && (tempname2 != tempname1 && tempname2 != tempname3) && (tempname3 != tempname1 && tempname3 != tempname2) ) // Checks if all 3 minister names (using the ran index's) are different
            {
                //nothing happens
            }
            else
            {
                throw new SameNameException(); //exception is thrown
            }
            // process above ensures none of the ministers are the same
        }

        private static string CalculateAnswer(DateTime term1, DateTime term2, DateTime term3)
        {
            if (term1.CompareTo(term2) < 0 && term1.CompareTo(term3) < 0)
            {
                return "1";
            }
            if (term2.CompareTo(term1) < 0 && term2.CompareTo(term3) < 0)
            {
                return "2";
            }
            if (term3.CompareTo(term1) < 0 && term3.CompareTo(term1) < 0)
            {
                return "3";
            }
            throw new TermCompareException();
        }

        private static void DisplayEndScore()
        {

            Console.Clear();
            Console.WriteLine($"User: {Player.name}");
            Console.WriteLine($"Your final score: {Player.score}");
            Console.WriteLine("Input R to restart! Input any other key to exit!");
            string endChoice = Console.ReadLine();
            if (endChoice == "R" || endChoice == "r")
            {
                Game.GameChoice();
            }
            else
            {
                return;
            }
        }
    }

    class Player
    {
        public static string name { get; set; }
        public static int score { get; set; }
    }

    public class SameIndexException : Exception
    {
        public SameIndexException() : base("Two or more the same PM record were referenced when generating a new set of questions!")
        {
        }
    }

    public class SameNameException : Exception
    {
        public SameNameException() : base("Two or more of the same PMs term were referenced when generating a new set of questions!")
        {
        }
    }

    public class TermCompareException : Exception
    {
        public TermCompareException() : base("An Error occured when comparing the given terms!")
        {
        }
    }

}


